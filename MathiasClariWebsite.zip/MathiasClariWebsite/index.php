<?php
    include_once 'header.php';
?>

    <div class="WelcomePage">
        <h2>Mathias Clari Drenik</h2>
        <p id="quote">Welcome to my portofolio!</p>
    </div>


<?php
    include_once 'footer.php';
?>

